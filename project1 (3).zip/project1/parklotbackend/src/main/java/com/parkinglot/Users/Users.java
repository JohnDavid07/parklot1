package com.parkinglot.Users;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Users {
	@Id private String userid;
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Users() {
	}

	public Users(String userid,String password) {
		super();
		this.userid = userid;
		this.password=password;
			}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
	

}
