package com.parkinglot.Users;

//import java.security.SecureRandom;
import java.util.List;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UsersService implements UserDetailsService {
	
	@Autowired
	private UsersRepository repo;
	
	 @Override
	    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

	        final Users user = this.repo.findById(userName).get();

	        if (user == null) {
	            throw new UsernameNotFoundException("User not found !!");
	        } else {
	            return new CustomUserDetails(user);
	        }
	 }

	public List<Users> listAll(){
		return repo.findAll();
	}
	
	public void save(Users users) {
		repo.save(users);
	}
	
	public Users get(String userid) {
		return repo.findById(userid).get();
	}
	
	public void delete(String userid) {
		repo.deleteById(userid);
	}
	
	public boolean checkuser(String userid) {
		return repo.existsById(userid);
		
	}
	
	public boolean checklogin(String userid) {
		if (checkuser(userid)) {
			return true;
		}
		else {
			return false;
		}
	}
	

}
