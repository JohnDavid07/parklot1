import { Injectable } from '@angular/core';
import { Vehicle } from '../models/vehicle.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  apiUrl = 'http://localhost:8080/vehicle';


  
  constructor(private _http: HttpClient) { }

  getVehicles(){
    let headers = new HttpHeaders().set("Authorization", `Bearer ${localStorage.getItem('token')}`)
    return this._http.get<Vehicle[]>(this.apiUrl,{headers});
  }

  addVehicle(vehicle){
    let headers = new HttpHeaders().set("Authorization", `Bearer ${localStorage.getItem('token')}`)
    return this._http.post<Vehicle>(this.apiUrl+'/add', vehicle, {headers})
  }
}
