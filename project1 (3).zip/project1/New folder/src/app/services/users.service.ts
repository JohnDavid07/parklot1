import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Users } from 'src/app/models/users.model';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
/*
  apiUrl = 'http://localhost:8080/users';

  httpOptions = {
    headers :new HttpHeaders({
      'Content-Type':'application/json'
    })    
  }
  
  constructor(private _http: HttpClient) { }

  loginCheck(loginDetails){
    return this._http.post<Boolean>(this.apiUrl+'/login',loginDetails, this.httpOptions);
  }
  httpOptions = {
  headers :new HttpHeaders({
    'Content-Type':'application/json'
  })    
}
getnerateToken(data){
    return this.http.post('http://localhost:8080/authenticate', data).subscribe(
      (result:any) => {localStorage.setItem('token', result.jwt)}
    )
  }
  retriveUser(user_id){
    let headers = new HttpHeaders().set("Authorization", `Bearer ${localStorage.getItem('token')}`)
    return this.http.get<User>('http://localhost:8080/users/'+user_id, {headers});
  }
*/
url='http://localhost:8080';

constructor(private _http: HttpClient) { 
  
}
generateToken(credentials:any){
 return this._http.post(`${this.url}/token`,credentials);
}


loginUser (token)
{
localStorage.setItem("token", token)
return true;
}

isLoggedIn()
{
let token=localStorage.getItem("token");
if (token==undefined || token==='' || token==null){
return false;
}else{
  return true;
}
}

logout(){
  localStorage.removeItem('token');
  localStorage.removeItem('username');
  return true;
}

getToken(){
  localStorage.getItem('token');
}


}


