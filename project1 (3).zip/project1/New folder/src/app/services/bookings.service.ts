import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Bookings } from '../models/bookings.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingsService {

  apiUrl = 'http://localhost:8080'
  
  httpOptions = {
    headers :new HttpHeaders({
      'Content-Type':'application/json'
    })    
  }

  constructor(private _http: HttpClient) { }

  getAllBookings(){
    let headers = new HttpHeaders().set("Authorization", `Bearer ${localStorage.getItem('token')}`)
    return this._http.get<Bookings[]>(this.apiUrl+'/bookings/allBookings')
  }

  getBookings(userid){
    let headers = new HttpHeaders().set("Authorization", `Bearer ${localStorage.getItem('token')}`)
    return this._http.get<Bookings[]>(this.apiUrl+'/bookings/getByUser/'+userid,{headers});
  }

  addBooking(id,bookings):Observable<Bookings>{
    bookings.locationid = id;
    //bookings.userid = sessionStorage.getItem('userid');
    bookings.userid = localStorage.getItem('username');
    console.log(bookings);
    let headers = new HttpHeaders().set("Authorization", `Bearer ${localStorage.getItem('token')}`)
    return this._http.post<Bookings>(this.apiUrl+'/bookings/add', bookings, {headers}); 
  }

  endBooking(bookingid){
    let headers = new HttpHeaders().set("Authorization", `Bearer ${localStorage.getItem('token')}`)
    return this._http.get<Boolean>(this.apiUrl+'/bookings/endBooking/'+bookingid,{headers});
  }

}
