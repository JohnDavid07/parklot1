import { Component,Inject , OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UsersService } from 'src/app/services/users.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  credentials={
    username:'',
    password:''
  }

 /* form = new FormGroup({
    userid : new FormControl('', Validators.required),
    password : new FormControl('', Validators.required)
  })
  
  constructor(private usersService: UsersService, public router: Router) { }

  ngOnInit(): void {
    this.checkLogin();
  }
     
  onSubmit() {
    var loginJson = JSON.stringify(this.form.value);
    this.usersService.loginCheck(loginJson)
    .subscribe((data => {
      if(data == true){
        var jsonData = JSON.parse(loginJson);
        this.storeLogin(jsonData['userid']);
        this.router.navigate(['/dashboard']);
      }
      else{
        alert("Invalid Login"); 
      }
    }))
  }

  form = new FormGroup({
    userid : new FormControl('', Validators.required),
    password : new FormControl('', Validators.required)
  })
  storeLogin(userid){
    sessionStorage.setItem("userid", userid); 
  }
  checkLogin(){
    if (sessionStorage.length != 0){
      this.router.navigate(['/']);
    }

    subscribe(
        (response:any)=>{
            console.log(response.token);
            this.userService.loginUser(response.token);
            this.router.navigate(['/dashboard']);
        },error=>{
          console.log(error);
        })
  }*/

  ngOnInit(): void {
    this.checkLogin();
  }

  constructor(private userService :UsersService,public router: Router){}

  onSubmit() {

    if((this.credentials.username!='' && this.credentials.password!='')&&(this.credentials.username!=null && this.credentials.password!=null)){

      this.userService.generateToken(this.credentials).subscribe(
        (response:any)=>{
            console.log(response.token);
            this.userService.loginUser(response.token);
            localStorage.setItem('username',this.credentials.username)
            this.router.navigate(['/dashboard']);
        },error=>{
          console.log(error);
        });    
  }
}


  checkLogin(){
    if (this.userService.isLoggedIn() == false){
      this.router.navigate(['/login']);
    }

}

}
