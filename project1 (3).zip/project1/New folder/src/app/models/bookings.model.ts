export class Bookings{
    bookingid: number;
    userid:string;
    vehicle_type: string;
    date: string;
    starttime: string;
    endtime : string;
    cost: string;
    slotid: string;
    paid: number;
    duration: number;

}