export class Slots{
    slotid: string;
    locationid:number;
    slotno: string;
    status:number;
    time:string;
    duration:number;
}