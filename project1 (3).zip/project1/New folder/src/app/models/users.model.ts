export class Users{
    userid : string;
    password: string;
}