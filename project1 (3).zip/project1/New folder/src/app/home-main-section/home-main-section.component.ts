import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from '../services/users.service';

@Component({
  selector: 'app-home-main-section',
  templateUrl: './home-main-section.component.html',
  styleUrls: ['./home-main-section.component.css']
})
export class HomeMainSectionComponent implements OnInit {

  constructor(private userservice:UsersService, private router : Router) { }

  ngOnInit(): void {
  }

  checkSession(){
    if (this.userservice.isLoggedIn()==false){
      
      this.router.navigate(['/login'])
      console.log('test')
    }
    else{
      this.router.navigate(['/dashboard'])
    }
  }
}
