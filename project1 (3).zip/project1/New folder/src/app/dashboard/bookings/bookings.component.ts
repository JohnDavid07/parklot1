import { Component, OnInit } from '@angular/core';
import { Bookings } from 'src/app/models/bookings.model';
import { BookingsService } from 'src/app/services/bookings.service';
import { Router } from '@angular/router';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css']
})
export class BookingsComponent implements OnInit {

  show: boolean;
  userid$ =  localStorage.getItem('username');
  bookings$: Bookings[] = [];

  constructor(private bookingsService: BookingsService, private userService:UsersService,
    public router: Router) { }

  ngOnInit() {
    this.checkLogin();
    this.getBookingById();
    
  }

  getBookingById(){
    return this.bookingsService.getBookings(this.userid$)
    .subscribe(data => {this.bookings$ = data, this.checkBookingFn();})
  }

  endBooking(bookingid){
    return this.bookingsService.endBooking(bookingid)
    .subscribe((data:{}) => {
      alert('Booking Ended');
      
      this.router.navigate(['dashboard/bookings'])
    })
  }
  checkBookingFn(){
    console.log()
    if (this.bookings$.length == 0){
      this.show = true
    }
    else{
      this.show = false
    }
  }

  checkLogin(){
    if (this.userService.isLoggedIn() == false){
      this.router.navigate(['/login']);
    }

}

}
